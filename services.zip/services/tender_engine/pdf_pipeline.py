from __future__ import annotations

import io
import re
from dataclasses import dataclass
from pathlib import Path

try:
    import pymupdf
except ImportError:  # old package name
    import fitz as pymupdf

from PIL import Image

from services.gigachat_client import ask_vision_json_schema, open_client

from .context import ProductDetector
from .data_source import DataTendersRepository
from .resolver import ResolverConfig, ValueResolver
from .schema import ProductContext, TenderRow
from .text import clean, norm, strip_marks
from .validator import TenderValidator


@dataclass
class PdfRowLayout:
    row: TenderRow
    target_rect: pymupdf.Rect
    page_index: int


class PdfTenderReader:
    """Читает PDF с координатами. Для скана использует Tesseract только как fallback."""

    def read(self, path: str | Path) -> tuple[list[PdfRowLayout], list[str]]:
        doc = pymupdf.open(str(path))
        layouts: list[PdfRowLayout] = []
        pages_text: list[str] = []
        for page_index, page in enumerate(doc):
            words = page.get_text("words")
            text = page.get_text("text")
            if not words and text.strip() == "":
                words = self._ocr_words(page)
                text = " ".join(w[4] for w in words)
            pages_text.append(clean(text))
            layouts.extend(self._rows_from_words(page_index, page, words))
        doc.close()
        return layouts, pages_text

    def _rows_from_words(self, page_index, page, words):
        if not words:
            return []
        lines = self._lines(words)
        answer_x = self._answer_column(lines, page.rect.width)
        result = []
        parent = ""
        section = ""
        counter = 0
        for line in lines:
            text = clean(" ".join(w[4] for w in line))
            num_match = re.match(r"^(\d+(?:\.\d+)*\.?)\b", text)
            number = num_match.group(1) if num_match else ""
            if answer_x is None:
                continue
            left, middle, right = self._split(line, answer_x, page.rect.width)
            parameter = clean(middle)
            requirement = clean(left)
            answer = clean(right)
            # В PDF текстовые координаты несовершенны, поэтому параметр ищем
            # между номером и первой правой колонкой, а требование/ответ — по x.
            if number:
                leading = re.sub(r"^\d+(?:\.\d+)*\.?\s*", "", parameter)
                parameter = leading or parameter
            if not parameter or parameter.lower().startswith("технические требования"):
                continue
            if text.endswith(":") and not answer:
                if number:
                    section = number.rstrip(".")
                parent = parameter
                continue
            row_id = f"p{page_index}_r{counter}"
            counter += 1
            key = self._field_key(parameter, parent)
            rect = self._answer_rect(line, answer_x, page.rect.width, page.rect.height)
            row = TenderRow(row_id, 0, page_index, number, parameter, requirement, answer, 0, parent, section, key)
            result.append(PdfRowLayout(row, rect, page_index))
        return result

    @staticmethod
    def _lines(words):
        grouped: dict[int, list] = {}
        for word in words:
            y = int(round(word[1] / 3.0))
            grouped.setdefault(y, []).append(word)
        out = []
        for line in grouped.values():
            out.append(sorted(line, key=lambda w: w[0]))
        return sorted(out, key=lambda x: min(w[1] for w in x))

    @staticmethod
    def _answer_column(lines, width):
        for line in lines[:30]:
            text = norm(" ".join(w[4] for w in line))
            if "предлагаемое участником" in text:
                xs = [w[0] for w in line]
                return min(xs) + width * 0.02
        # Для типового тендерного PDF ответа находится в правой трети страницы.
        return width * 0.72

    @staticmethod
    def _split(line, answer_x, width):
        left, middle, right = [], [], []
        # Эвристические границы: requirement чаще начинается между 35–60% ширины,
        # answer — после 70%. Эта логика не используется для DOCX.
        for word in line:
            x = word[0]
            if x >= answer_x:
                right.append(word)
            elif x >= width * 0.34:
                middle.append(word)
            else:
                left.append(word)
        return left, middle, right

    @staticmethod
    def _answer_rect(line, x, width, height):
        ys = [w[1] for w in line] + [w[3] for w in line]
        y0, y1 = min(ys), max(ys)
        return pymupdf.Rect(x, max(0, y0 - 1), width - 8, min(height, y1 + 3))

    @staticmethod
    def _field_key(parameter, parent):
        from .rules import field_key
        return field_key(parameter, parent)

    def _ocr_words(self, page):
        try:
            import pytesseract
            pix = page.get_pixmap(dpi=180, alpha=False)
            img = Image.open(io.BytesIO(pix.tobytes("png")))
            data = pytesseract.image_to_data(img, lang="rus+eng", output_type=pytesseract.Output.DICT)
            sx, sy = page.rect.width / img.width, page.rect.height / img.height
            words = []
            for i, txt in enumerate(data["text"]):
                txt = clean(txt)
                if not txt:
                    continue
                x, y = data["left"][i] * sx, data["top"][i] * sy
                w, h = data["width"][i] * sx, data["height"][i] * sy
                words.append((x, y, x + w, y + h, txt))
            return words
        except Exception as exc:
            print(f"[PDF][OCR] {exc}")
            return []


class PdfTenderWriter:
    def write(self, path: str | Path, layouts: list[PdfRowLayout]) -> None:
        doc = pymupdf.open(str(path))
        for layout in layouts:
            row = layout.row
            if not row.proposed_value:
                continue
            page = doc[layout.page_index]
            rect = layout.target_rect
            page.draw_rect(rect, color=None, fill=None, overlay=True)
            # Закрываем исходный ответ белым прямоугольником только внутри ответной зоны.
            page.draw_rect(rect, color=(1, 1, 1), fill=(1, 1, 1), overlay=True)
            text = strip_marks(row.proposed_value) + (row.mark or "")
            page.insert_textbox(rect, text, fontsize=8, fontname="helv", align=0, overlay=True)
        doc.saveIncr()
        doc.close()


class PdfTenderFillingEngine:
    def __init__(self, data_tenders_root: str | Path, *, ai_enabled: bool = True):
        self.reader = PdfTenderReader()
        self.repo = DataTendersRepository(data_tenders_root)
        self.resolver = ValueResolver(self.repo, ResolverConfig(overwrite_existing=False))
        self.detector = ProductDetector()
        self.validator = TenderValidator()
        self.ai_enabled = ai_enabled

    def fill(self, input_path: str | Path, output_path: str | Path, *, overwrite_existing: bool = False) -> dict:
        layouts, pages = self.reader.read(input_path)
        rows = [x.row for x in layouts]
        context = self.detector.detect(rows, pages)
        if not context.model:
            raise ValueError("Не удалось определить модель ТТ в PDF.")
        unresolved = []
        for row in rows:
            self.resolver.config = ResolverConfig(overwrite_existing=overwrite_existing)
            decision = self.resolver.resolve_initial(row, context)
            row.proposed_value, row.source, row.mark, row.confidence, row.reason = decision.value, decision.source, decision.mark, decision.confidence, decision.reason
            row.evidence = list(decision.evidence)
            if not row.proposed_value:
                unresolved.append(row)
        if self.ai_enabled and unresolved:
            self._vision_or_text_ai(unresolved, input_path, context)
        for row in rows:
            if row.proposed_value:
                ok, reason = self.validator.validate(row, row.proposed_value, rows)
                if not ok:
                    row.proposed_value, row.mark, row.source, row.reason = "", "", "UNRESOLVED", reason
        target = Path(output_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        doc = pymupdf.open(str(input_path))
        temp = target.with_suffix(target.suffix + ".tmp.pdf")
        doc.save(str(temp))
        doc.close()
        PdfTenderWriter().write(temp, layouts)
        temp.replace(target)
        return {"output": str(target), "filled": sum(bool(r.proposed_value) for r in rows), "unresolved": [r.row_id for r in rows if not r.proposed_value], "detected_type": context.model, "voltage": context.voltage}

    def _vision_or_text_ai(self, rows, pdf_path, context: ProductContext):
        # Один снимок страницы на блок, только когда OCR/детерминированный проход не дал ответа.
        try:
            with open_client() as client:
                doc = pymupdf.open(str(pdf_path))
                for page_index in sorted({r.row_id.split("_")[0][1:] for r in rows}):
                    page_no = int(page_index)
                    pix = doc[page_no].get_pixmap(dpi=140, alpha=False)
                    image = pix.tobytes("png")
                    payload = [{"id": r.row_id, "number": r.number, "parameter": r.parameter, "requirement": r.requirement, "parent": r.parent_context} for r in rows if r.row_id.startswith(f"p{page_no}_")]
                    response = ask_vision_json_schema(client, image, self._prompt(context, payload), self._schema())
                    for item in response.get("results", []) or []:
                        row = next((x for x in rows if x.row_id == item.get("id")), None)
                        if row and float(item.get("confidence", 0) or 0) >= 0.55:
                            value = clean(item.get("value", ""))
                            if value:
                                row.proposed_value = value
                                row.source = "AI_VISION"
                                row.mark = "*" if "*" in row.requirement else "**"
                                row.confidence = float(item.get("confidence", 0))
                                row.reason = clean(item.get("reason", ""))
                doc.close()
        except Exception as exc:
            print(f"[PDF][AI] пропуск: {exc}")

    @staticmethod
    def _prompt(context, payload):
        return f"Определи значения только для этих строк PDF. Нельзя переносить соседнюю строку. Модель={context.model}, U={context.voltage}. Дай пустое значение, если факта нет. Строки={payload}"

    @staticmethod
    def _schema():
        return {"type":"object","additionalProperties":False,"properties":{"results":{"type":"array","items":{"type":"object","additionalProperties":False,"properties":{"id":{"type":"string"},"value":{"type":"string"},"confidence":{"type":"number"},"reason":{"type":"string"}},"required":["id","value","confidence","reason"]}}},"required":["results"]}
