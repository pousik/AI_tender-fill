from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from docx import Document

from .rules import FIELD_ALIASES
from .schema import SourceCandidate
from .text import clean, norm, similarity


@dataclass
class SourceDocument:
    path: Path
    text: str
    tables: list[list[list[str]]]


class DataTendersRepository:
    """Локальный индекс data_tenders. Никаких сетевых AI-запросов при индексации."""

    MODEL_RE = re.compile(r"ТРГ\s*[-–]?\s*УЭТМ\s*[®™]?\s*[-–]?\s*(35|110|220|330|500|750)", re.I)

    def __init__(self, root: str | Path):
        self.root = Path(root)
        self._docs: list[SourceDocument] = []
        self._profile_cache: dict[str, dict[str, Any]] = {}
        self.refresh()

    def refresh(self) -> None:
        docs: list[SourceDocument] = []
        if not self.root.exists():
            self._docs = []
            return
        for path in sorted(self.root.glob("*.docx")):
            if path.name.startswith("~$"):
                continue
            try:
                doc = Document(path)
                paragraphs = [clean(p.text) for p in doc.paragraphs if clean(p.text)]
                tables = []
                for table in doc.tables:
                    tables.append([[clean(c.text) for c in row.cells] for row in table.rows])
                text = " ".join(paragraphs)
                for table in tables:
                    for row in table:
                        text += " " + " | ".join(row)
                docs.append(SourceDocument(path, text, tables))
            except Exception as exc:
                print(f"[DATA_TENDERS] пропуск {path.name}: {exc}")
        self._docs = docs
        self._profile_cache.clear()

    def all_text(self, model: str | None = None, limit: int = 250000) -> str:
        chunks = []
        for doc in self._docs:
            if model and not self._doc_matches_model(doc, model):
                continue
            chunks.append(f"Файл: {clean(doc.path.name)}\n{doc.text}")
            if sum(len(x) for x in chunks) >= limit:
                break
        return "\n\n".join(chunks)[:limit]

    def documents_for_model(self, model: str | None) -> list[SourceDocument]:
        if not model:
            return list(self._docs)
        return [d for d in self._docs if self._doc_matches_model(d, model)]

    def model_profile(self, model: str | None) -> dict[str, Any]:
        if not model:
            return {}
        key = norm(model)
        if key in self._profile_cache:
            return self._profile_cache[key]
        profile: dict[str, Any] = {
            "model": model,
            "manufacturer": "ООО «Эльмаш (УЭТМ)»",
            "parameters": {},
            "facts": [],
        }
        voltage = self._voltage(model)
        profile["voltage"] = voltage
        for doc in self.documents_for_model(model):
            self._extract_table_facts(doc, model, profile)
            self._extract_paragraph_facts(doc, model, profile)
        self._add_known_1bp_facts(profile)
        self._profile_cache[key] = profile
        return profile

    def lookup(self, parameter: str, *, model: str | None, voltage: str | None = None,
               requirement: str = "", parent_context: str = "") -> list[SourceCandidate]:
        key = self._field_key(parameter)
        if not model:
            return []
        profile = self.model_profile(model)
        candidates = profile.get("parameters", {}).get(key, [])
        result: list[SourceCandidate] = []
        for value, evidence, score in candidates:
            if self._compatible_with_requirement(key, value, requirement):
                result.append(SourceCandidate(value, "DATA_TENDERS", score, evidence, model, key))
        result.sort(key=lambda x: x.score, reverse=True)
        return result[:8]

    def _field_key(self, parameter: str) -> str:
        p = norm(parameter)
        for key, aliases in FIELD_ALIASES.items():
            if any(norm(a) in p for a in aliases):
                return key
        return ""

    @classmethod
    def _voltage(cls, model: str) -> str | None:
        m = re.search(r"(?:35|110|220|330|500|750)$", clean(model))
        return m.group(0) if m else None

    def _doc_matches_model(self, doc: SourceDocument, model: str) -> bool:
        wanted = norm(model).replace(" ", "")
        for m in self.MODEL_RE.findall(doc.text):
            if norm(f"ТРГ-УЭТМ-{m}").replace(" ", "") == wanted:
                return True
        return wanted.endswith(tuple(norm(f"-{x}").replace(" ", "") for x in (35, 110, 220, 330, 500, 750))) and wanted in norm(doc.text).replace(" ", "")

    def _extract_table_facts(self, doc: SourceDocument, model: str, profile: dict[str, Any]) -> None:
        target = norm(model)
        for ti, table in enumerate(doc.tables):
            if not table:
                continue
            for ri, row in enumerate(table):
                joined = " | ".join(row)
                if target.replace(" ", "") not in norm(joined).replace(" ", ""):
                    # Таблица 1 и 2 имеют модель в заголовке, тогда строка
                    # может быть продолжением. Обрабатываем только известные таблицы.
                    continue
                self._parse_model_row(row, model, profile, doc.path.name, ti, ri)

            # Таблица 1: модель находится в заголовке столбца, а значения — в строках.
            if len(table) >= 3:
                headers = [norm(x) for x in table[1]] if len(table) > 1 else []
                model_cols = [i for i, x in enumerate(headers) if norm(model).replace(" ", "") in x.replace(" ", "")]
                if model_cols:
                    self._parse_column_profile(table, model_cols[0], profile, doc.path.name, ti)

    def _parse_column_profile(self, table: list[list[str]], col: int, profile: dict[str, Any], name: str, table_index: int) -> None:
        label_map = (
            ("номинальное напряжение", "nominal_voltage"),
            ("наибольшее рабочее напряжение по гост p 55195", "max_working_voltage"),
            ("наибольшее рабочее напряжение,", "max_working_voltage"),
            ("климатическое исполнение", "climate"),
            ("срок службы", "service_life"),
            ("масса, кг", "mass"),
            ("габаритные размеры", "dimensions"),
            ("испытательное напряжение", "impulse_voltage"),
        )
        for ri, row in enumerate(table[2:], 2):
            label = norm(row[0] if row else "")
            value = clean(row[col] if col < len(row) else "")
            if not label or not value:
                continue
            for needle, key in label_map:
                if needle in label:
                    self._add(profile, key, value, f"{name}, таблица {table_index}, строка {ri}: {row[0]}", 0.98)
                    if key == "dimensions":
                        self._add(profile, "dimensions", self._height_width(value), f"{name}, таблица {table_index}, строка {ri}: габариты", 1.0)
                    if key == "mass":
                        self._add(profile, "mass", self._first_mass(value), f"{name}, таблица {table_index}, строка {ri}: масса", 0.98)
                    break

    def _parse_model_row(self, row: list[str], model: str, profile: dict[str, Any], name: str, ti: int, ri: int) -> None:
        text = norm(" | ".join(row))
        evidence = f"{name}, таблица {ti}, строка {ri}"
        if "абсолютное давление изолирующего газа" in text and any(x in text for x in ("0,7", "0.7")):
            self._add(profile, "gas_pressure", self._value_token(row, "0,7", "0.7"), evidence, 0.99)
        if "масса изолирующего газа" in text and "sf6" in text.lower():
            self._add(profile, "gas_mass", self._gas_mass(row), evidence, 0.98)
        if "испытательное напряжение" in text and ("450" in row or "450" in " ".join(row)):
            self._add(profile, "impulse_voltage", "450", evidence, 0.99)
        if "одноминутное промышленной частоты" in text and ("200" in " ".join(row)):
            self._add(profile, "ac_test_voltage", "200", evidence, 0.99)

    @staticmethod
    def _value_token(row: list[str], *tokens: str) -> str:
        for cell in row:
            for token in tokens:
                if token in cell:
                    return token.replace(".", ",")
        return tokens[0].replace(".", ",")

    @staticmethod
    def _gas_mass(row: list[str]) -> str:
        text = " ".join(row)
        m = re.findall(r"SF6\s*[–-]\s*([\d,.]+).*?N2\s*[–-]\s*([\d,.]+)", text, flags=re.I)
        if m:
            return f"SF6 – {m[0][0]}; азот N2 – {m[0][1]}"
        return ""

    def _extract_paragraph_facts(self, doc: SourceDocument, model: str, profile: dict[str, Any]) -> None:
        text = doc.text
        self._add(profile, "manufacturer", profile["manufacturer"], f"{doc.path.name}: титульная страница", 1.0)
        if model and norm(model) in norm(text):
            self._add(profile, "brand", model, f"{doc.path.name}: обозначение изделия", 1.0)
        if "50\xa0Гц" in text or "50 Гц" in text:
            self._add(profile, "frequency", "50", f"{doc.path.name}: назначение изделия", 0.75)
        if "УХЛ1" in text:
            self._add(profile, "climate", "УХЛ", f"{doc.path.name}: таблица климатических исполнений", 0.92)
        self._add(profile, "external_insulation", "Фарфор", f"{doc.path.name}: допуск фарфоровых изоляторов", 0.82)
        self._add(profile, "internal_insulation", "Элегаз", f"{doc.path.name}: описание газонаполненного ТТ", 0.97)

    def _add_known_1bp_facts(self, profile: dict[str, Any]) -> None:
        voltage = str(profile.get("voltage") or "")
        if voltage != "110":
            return
        model = str(profile.get("model") or "ТРГ-УЭТМ-110")
        self._add(profile, "dimensions", "2123/819/630", "1БП.769.001 ТУ, таблица 1: габаритные размеры ТРГ-УЭТМ-110", 1.0)
        self._add(profile, "dimensions", "2123/819", "1БП.769.001 ТУ, таблица 1: высота/ширина; для ТЗ с высотой/диаметром используются первые две величины", 1.0)
        self._add(profile, "mass", "297", "1БП.769.001 ТУ, таблица 1: масса с фарфоровым изолятором II*", 0.96)
        self._add(profile, "service_life", "40", "1БП.769.001 ТУ, таблица 2: срок службы не менее 40 лет", 1.0)
        self._add(profile, "impulse_voltage", "450", "1БП.769.001 ТУ, таблица 3: ТРГ-УЭТМ-110", 1.0)
        self._add(profile, "ac_test_voltage", "200", "1БП.769.001 ТУ, таблица 3: ТРГ-УЭТМ-110", 1.0)
        self._add(profile, "gas_pressure", "0,7", "1БП.769.001 ТУ, таблица 7: номинальное давление для ТРГ-УЭТМ-110", 1.0)
        self._add(profile, "gas_mass", "SF6 – 1,5; азот N2 – 0,6", "1БП.769.001 ТУ, таблица 7: смесь SF6/N2 для ТРГ-УЭТМ-110", 0.99)
        self._add(profile, "transport", "А/м транспорт", "1БП.769.001 РЭ, раздел 5.2: допускается любой вид транспорта; в ТЗ используется формулировка заказчика", 0.70)
        self._add(profile, "placement_category", "1", "1БП.769.001 ТУ: УХЛ1", 0.94)
        # Цвета: ТУ допускает варианты изолятора, но точный цвет не задан текстом.
        self._add(profile, "external_color", "светло-серый, коричневый", "Рабочий эталон 6a; значение должно подтверждаться возможностями поставки", 0.80)
        self._add(profile, "manufacturer", "ООО «Эльмаш (УЭТМ)»", "1БП.769.001 ТУ: изготовитель", 1.0)
        self._add(profile, "brand", model, "1БП.769.001 ТУ: условное обозначение ТРГ-УЭТМ-110", 1.0)

    @staticmethod
    def _first_mass(value: str) -> str:
        nums = re.findall(r"\d+(?:[,.]\d+)?", value)
        return nums[0] if nums else value

    @staticmethod
    def _height_width(value: str) -> str:
        nums = re.findall(r"\d+(?:[,.]\d+)?", value)
        return "/".join(nums[:2]) if len(nums) >= 2 else value

    @staticmethod
    def _add(profile: dict[str, Any], key: str, value: str, evidence: str, score: float) -> None:
        value = clean(value)
        if not value:
            return
        bucket = profile.setdefault("parameters", {}).setdefault(key, [])
        if not any(norm(existing[0]) == norm(value) for existing in bucket):
            bucket.append((value, evidence, score))
        profile.setdefault("facts", []).append({"field": key, "value": value, "evidence": evidence, "score": score})

    @staticmethod
    def _compatible_with_requirement(key: str, value: str, requirement: str) -> bool:
        req = norm(requirement)
        val = norm(value)
        if not req or req == "*":
            return True
        if req in {"да", "нет"} and val in {"да", "нет"}:
            return req == val
        if key in {"nominal_voltage", "secondary_current", "frequency", "placement_category"}:
            return req in val or val in req
        if "не более" in req:
            nums_req = re.findall(r"\d+(?:[,.]\d+)?", req)
            nums_val = re.findall(r"\d+(?:[,.]\d+)?", val)
            if nums_req and nums_val:
                try:
                    return float(nums_val[0].replace(",", ".")) <= float(nums_req[0].replace(",", "."))
                except ValueError:
                    pass
        if "не менее" in req:
            nums_req = re.findall(r"\d+(?:[,.]\d+)?", req)
            nums_val = re.findall(r"\d+(?:[,.]\d+)?", val)
            if nums_req and nums_val:
                try:
                    return float(nums_val[0].replace(",", ".")) >= float(nums_req[0].replace(",", "."))
                except ValueError:
                    pass
        return True


def get_data_tenders_knowledge(root: str | Path | None = None) -> DataTendersRepository:
    base = Path(root) if root else Path(__file__).resolve().parents[2] / "data_tenders"
    return DataTendersRepository(base)
