from __future__ import annotations

import json
import shutil
import sys
import tempfile
from pathlib import Path

from docx import Document
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from models.tr_type import Base  # noqa: E402
from services.tender_engine.docx_reader import DocxTableReader  # noqa: E402
from services.tender_engine.pipeline import TenderFillingEngine  # noqa: E402

GOOD = Path("/mnt/data/6da5de63-95fe-4730-9fc1-16683ad9b29c Технические требования ПС Нижний Куранах(заполнена)(2).docx")
BAD = Path("/mnt/data/Заполненный_6da5de63-95fe-4730-9fc1-16683ad9b29c Технические требования ПС Нижний Куранах(1).docx")


def cell_text(cell):
    return " ".join((cell.text or "").split())


def read_answers(path: Path):
    snap = DocxTableReader().read(Document(path))
    return {r.identity: (r.current_value, r.target_cell_index) for r in snap.rows if r.parameter}


def main() -> int:
    with tempfile.TemporaryDirectory() as td:
        db_path = Path(td) / "test.db"
        engine = create_engine(f"sqlite:///{db_path}")
        Base.metadata.create_all(engine)
        Session = sessionmaker(bind=engine)
        session = Session()
        try:
            filling = TenderFillingEngine(ROOT / "data_tenders", ai_enabled=False, overwrite_existing=True)
            learned = filling.capture_final_docx(GOOD, session, specialist_name="test")
            assert learned["saved_rows"] >= 70, learned

            # Проверяем, что вложенные строки имеют 5 физических ячеек и пишутся именно в последнюю.
            snapshot = DocxTableReader().read(Document(GOOD))
            nested = [r for r in snapshot.rows if r.parent_context.startswith("Обмотка ") and r.parameter in {"Класс точности, %", "Номинальная нагрузка, ВА"}]
            assert len(nested) == 6
            assert all(r.target_cell_index == 4 for r in nested)
            assert {r.field_key for r in snapshot.rows if r.number in {"6.5", "6.6"}} == {"secondary_ac_test", "interturn_test"}

            output = Path(td) / "corrected.docx"
            result = filling.fill_docx(BAD, output, session)
            assert result["filled"] >= 70, result

            good = read_answers(GOOD)
            fixed = read_answers(output)
            checked = 0
            mismatches = []
            for identity, (good_value, _) in good.items():
                if identity not in fixed:
                    mismatches.append((identity, "missing"))
                    continue
                fixed_value = fixed[identity][0]
                # Footnote stars (****) и AI markers (**/*) не влияют на семантическое значение.
                norm_good = " ".join(good_value.rstrip("*").split())
                norm_fixed = " ".join(fixed_value.rstrip("*").split())
                if norm_good != norm_fixed:
                    mismatches.append((identity, norm_good, norm_fixed))
                checked += 1

            assert not mismatches, json.dumps(mismatches[:10], ensure_ascii=False, indent=2)
            shutil.copy2(output, Path("/mnt/data/Заполненный_6a_исправленный.docx"))
            shutil.copy2(output.with_suffix(".docx.audit.json"), Path("/mnt/data/Заполненный_6a_исправленный.docx.audit.json"))
            print(json.dumps({"learned": learned, "fill": result, "checked": checked, "mismatches": len(mismatches)}, ensure_ascii=False, indent=2))
        finally:
            session.close()


if __name__ == "__main__":
    raise SystemExit(main())
