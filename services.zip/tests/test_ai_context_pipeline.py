"""Быстрые проверки нового контекстного AI-пайплайна без вызова API."""
from pathlib import Path
import unittest

from docx import Document

from services.ai_context import ContextBuilder
from services.ai_review import AIReviewService
from services.data_tenders_knowledge import get_data_tenders_knowledge
from services.search_docx_AI import (
    _algorithm_fill,
    _build_self_context,
    _determine_type,
    _infer_target_product_context,
    _prepare_ai_targets,
    extract_doc_items,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SAMPLE_DOC = next(PROJECT_ROOT.glob("*.docx"))


class AIContextPipelineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.doc = Document(SAMPLE_DOC)
        cls.items, cls.extra = extract_doc_items(cls.doc)
        cls.tr_type, cls.voltage = _determine_type(None, cls.items, cls.extra["document"])
        for item in cls.items:
            context = _infer_target_product_context(item, cls.extra["document"])
            if (
                not context.get("model")
                and context.get("product_kind") == "трансформатор тока"
                and cls.tr_type
                and str(cls.tr_type.name).lower().startswith("трг-уэтм")
            ):
                context["model"] = cls.tr_type.name
                context["voltage"] = context.get("voltage") or cls.voltage
            item["_product_context"] = context
        cls.data_kb = get_data_tenders_knowledge()
        cls.algorithm_items = _algorithm_fill(
            None,
            cls.items,
            cls.tr_type,
            cls.voltage,
            data_kb=cls.data_kb,
        )
        cls.self_profile = _build_self_context(cls.algorithm_items, cls.extra["document"])
        cls.ai_targets, _ = _prepare_ai_targets(cls.algorithm_items, cls.self_profile)

    def test_current_document_is_complete_context(self):
        context = ContextBuilder().build_current_document(
            self.extra["document"], self.algorithm_items
        )
        self.assertIn("ТЕКУЩИЙ ФАЙЛ: ПОЛНЫЙ КОНТЕКСТ", context.text)
        self.assertGreater(len(context.text), 5000)

    def test_data_tenders_contains_all_files(self):
        context = ContextBuilder().build_data_tenders(self.data_kb, chunk_chars=26000)
        self.assertEqual(context.file_count, 3)
        self.assertEqual(context.record_count, 1368)
        self.assertEqual(context.model_count, 6)
        self.assertGreater(len(context.chunks), 1)

    def test_ai_index_keeps_all_models_and_directory_files(self):
        context = ContextBuilder().build_data_tenders(self.data_kb, chunk_chars=26000)
        for model in (
            "ТРГ-УЭТМ-35", "ТРГ-УЭТМ-110", "ТРГ-УЭТМ-220",
            "ТРГ-УЭТМ-330", "ТРГ-УЭТМ-500", "ТРГ-УЭТМ-750",
        ):
            self.assertIn(model, context.ai_text)
        for file_name in [p.name for p in self.data_kb._files()]:
            self.assertIn(file_name, context.ai_text)
        self.assertIn("record_count", context.ai_text)
        self.assertIn("масса", context.ai_text.lower())
        self.assertIn("габаритные размеры", context.ai_text.lower())

    def test_data_scan_prompts_fit_safe_limit(self):
        builder = ContextBuilder()
        current = builder.build_current_document(self.extra["document"], self.algorithm_items)
        targets = builder.build_targets(self.ai_targets)
        service = AIReviewService(None)
        focus = service._scan_target_focus(targets)
        chunk_size = service._scan_chunk_size(len(current.text), len(focus))
        data = builder.build_data_tenders(self.data_kb, chunk_chars=chunk_size)
        self.assertGreater(len(data.ai_chunks), 1)
        for index, chunk in enumerate(data.ai_chunks, start=1):
            prompt = service._build_target_scan_prompt(
                current=current.text,
                data_chunk=chunk,
                target_focus=focus,
                chunk_number=index,
                total_chunks=len(data.ai_chunks),
            )
            self.assertLessEqual(len(prompt), service.safe_limit)

    def test_item_context_can_carry_model_and_voltage(self):
        # Проверяем не конкретный тестовый DOCX, а сам контракт контекстного
        # слоя: когда секция определена как ТТ и глобальная модель совместима,
        # модель и напряжение должны стать частью target context.
        item = dict(self.items[0])
        item["_product_context"] = {
            "product_kind": "трансформатор тока",
            "model": self.tr_type.name,
            "voltage": self.voltage,
        }
        item["_ai_data_candidates"] = ["пример"]
        target = ContextBuilder().build_targets([item])[0]
        self.assertEqual(target.product_context.get("product_kind"), "трансформатор тока")
        self.assertEqual(target.product_context.get("model"), self.tr_type.name)
        self.assertEqual(target.product_context.get("voltage"), self.voltage)

    def test_scan_processes_every_data_chunk(self):
        builder = ContextBuilder()
        current = builder.build_current_document(self.extra["document"], self.algorithm_items)
        targets = builder.build_targets(self.ai_targets[:2])
        service = AIReviewService(object())

        calls = []
        original = __import__("services.ai_review", fromlist=["ask_json_schema"]).ask_json_schema
        module = __import__("services.ai_review", fromlist=["ask_json_schema"])
        module.ask_json_schema = lambda client, prompt, schema, **kwargs: (
            calls.append(prompt) or {"candidates": []}
        )
        try:
            data = builder.build_data_tenders(self.data_kb, chunk_chars=18000)
            found = service._scan_all_data_tenders_chunks(
                current=current,
                data_chunks=data.ai_chunks,
                targets=targets,
            )
            self.assertEqual(found, [])
            self.assertEqual(len(calls), len(data.ai_chunks))
            for prompt in calls:
                self.assertIn("ПОЛНЫЙ ТЕКУЩИЙ ДОКУМЕНТ", prompt)
                self.assertIn("ЧАСТЬ DATA_TENDERS", prompt)
        finally:
            module.ask_json_schema = original


if __name__ == "__main__":
    unittest.main()
